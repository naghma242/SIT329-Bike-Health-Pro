#include <stdio.h>
#include <io.h>
#include <unistd.h>
#include "system.h"

#define ADC_BASE_ADDR ADC_LTC2308_BASE  // Assuming ADC_LTC2308_BASE is defined in "system.h"

int main() {
    printf("Starting ADC reading...\n");

    while (1) {
        // Initiate ADC measurement for a specific channel
        // Assuming channel 0, modify as necessary
        IOWR(ADC_BASE_ADDR, 0x00, 0x00);  // Start conversion command
        IOWR(ADC_BASE_ADDR, 0x00, 0x01);  // Actual channel command (might vary depending on ADC setup)
        IOWR(ADC_BASE_ADDR, 0x00, 0x00);  // End conversion command

        // Wait for ADC conversion to complete
        while ((IORD(ADC_BASE_ADDR, 0x00) & 0x01) == 0x00);

        // Read ADC value
        uint16_t adcValue = IORD(ADC_BASE_ADDR, 0x01);  // Assuming the data is available at offset 0x01

        // Print the ADC value
        printf("ADC Value: %d\n", adcValue);

        usleep(500*1000);  // Delay for 500 ms before next reading
    }

    return 0;
}
